<?php

return [
    'navigation' => [
        'dashboard'           => 'لوحة التحكم',
        'contact'             => 'جهات الاتصال',
        'sale'                => 'المبيعات',
        'purchase'            => 'المشتريات',
        'invoice'             => 'الفواتير',
        'accounting'          => 'المحاسبة',
        'inventory'           => 'المخزون',
        'maintenance'         => 'الصيانة',
        'manufacturing'       => 'التصنيع',
        'project'             => 'المشاريع',
        'employee'            => 'الموظفين',
        'time-off'            => 'الإجازات',
        'recruitment'         => 'التوظيف',
        'website'             => 'الموقع الإلكتروني',
        'plugin'              => 'الإضافات',
        'setting'             => 'الإعدادات',
        'help'                => 'المساعدة',
        'point-of-sale'       => 'نقطة البيع',
        'barcode'             => 'الباركود',
    ],

    'app-menu' => [
        'label' => 'التطبيقات',
        'close' => 'إغلاق',
    ],
];
